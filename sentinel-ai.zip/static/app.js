/* Sentinel AI — frontend logic */
const $ = (s) => document.querySelector(s);
const $$ = (s) => [...document.querySelectorAll(s)];

const state = {
  loc: { name: "Dimapur, Nagaland", lat: 25.9044, lon: 93.7267 }, // default demo home
  env: null, demo: false, map: null, markers: [], chatHistory: [],
};

/* ---------- Demo scenarios (clearly labelled, NOT live) ---------- */
const DEMO = {
  normal: null, // live data passes through
  heavy_rain: {
    weather: { temp: 26.4, feels: 29.1, humidity: 93, condition: "Moderate rain", icon: "🌧️", precip: 4.2, cloud: 100, wind: 18, gusts: 32, fetched_at: "DEMO" },
    next_rain: { time: "tonight", probability: 95, precip_mm: 8.4, hours_from_now: 1 },
    air: { us_aqi: 38, category: "Good" },
    flood_risk: { risk_score: 74, risk_level: "HIGH", confidence: "moderate", data_quality: "moderate",
      factors: ["Heavy forecast rainfall accumulation (58 mm in 24h)", "High rainfall intensity (up to 11 mm/h)", "High precipitation probability (95%)", "Low elevation (147 m) increases water-accumulation potential"],
      data_limitations: ["DEMO DATA — NOT LIVE", "Regional estimate; cannot resolve individual colony roads or drains."],
      disclaimer: "AI-assisted environmental risk estimate, not an official flood warning." },
    earthquakes: { count: 0, nearest: [] },
    _demo: true,
  },
  flood: {
    weather: { temp: 25.8, feels: 28.6, humidity: 97, condition: "Heavy rain", icon: "🌧️", precip: 12.6, cloud: 100, wind: 24, gusts: 41, fetched_at: "DEMO" },
    next_rain: { time: "now", probability: 100, precip_mm: 12.6, hours_from_now: 0 },
    air: { us_aqi: 44, category: "Good" },
    flood_risk: { risk_score: 86, risk_level: "VERY HIGH", confidence: "moderate", data_quality: "moderate",
      factors: ["Extreme rainfall accumulation (92 mm in 24h)", "Very high intensity (up to 18 mm/h)", "Saturated soil reduces infiltration", "Regional river discharge 1.8× its average (river-level indicator)"],
      data_limitations: ["DEMO DATA — NOT LIVE", "Regional estimate; cannot resolve individual colony roads or drains."],
      disclaimer: "AI-assisted environmental risk estimate, not an official flood warning." },
    earthquakes: { count: 0, nearest: [] },
    _demo: true,
  },
  earthquake: {
    weather: { temp: 29.6, feels: 33.2, humidity: 71, condition: "Partly cloudy", icon: "⛅", precip: 0, cloud: 62, wind: 9, gusts: 14, fetched_at: "DEMO" },
    next_rain: null,
    air: { us_aqi: 52, category: "Moderate" },
    flood_risk: { risk_score: 22, risk_level: "LOW", confidence: "moderate", data_quality: "moderate",
      factors: ["No significant flood-driving factors in the next 24h"],
      data_limitations: ["DEMO DATA — NOT LIVE"], disclaimer: "AI-assisted environmental risk estimate, not an official flood warning." },
    earthquakes: { count: 1, nearest: [{ mag: 5.2, place: "Simulated event near the Naga Hills", distance_km: 180, depth_km: 45, time: Date.now() - 3600e3, alert: null, _demo: true }] },
    _demo: true,
  },
  poor_air: {
    weather: { temp: 31.2, feels: 35.0, humidity: 58, condition: "Haze", icon: "🌫️", precip: 0, cloud: 30, wind: 6, gusts: 10, fetched_at: "DEMO" },
    next_rain: null,
    air: { us_aqi: 178, category: "Unhealthy", pm2_5: 96.4, pm10: 141.2 },
    flood_risk: { risk_score: 15, risk_level: "LOW", confidence: "moderate", data_quality: "moderate",
      factors: ["No significant flood-driving factors in the next 24h"],
      data_limitations: ["DEMO DATA — NOT LIVE"], disclaimer: "AI-assisted environmental risk estimate, not an official flood warning." },
    earthquakes: { count: 0, nearest: [] },
    _demo: true,
  },
};
let demoScenario = "heavy_rain";

/* ---------- Navigation ---------- */
function switchView(v) {
  $$(".view").forEach((x) => x.classList.remove("active"));
  $("#view-" + v).classList.add("active");
  $$(".nav-btn,.bn-btn").forEach((b) => b.classList.toggle("active", b.dataset.view === v));
  if (v === "map") initMap();
  if (v === "alerts") loadAlerts();
  if (v === "places") loadPlaces();
}
$$(".nav-btn,.bn-btn").forEach((b) => b.addEventListener("click", () => switchView(b.dataset.view)));

/* ---------- Environment load ---------- */
async function loadEnvironment() {
  const { lat, lon, name } = state.loc;
  if (state.demo && DEMO[demoScenario]) {
    renderEnv({ ...DEMO[demoScenario], location: state.loc, hourly: null, daily: null, _demo: true });
    return;
  }
  try {
    const r = await fetch(`/api/environment?lat=${lat}&lon=${lon}&name=${encodeURIComponent(name)}`);
    const j = await r.json();
    state.env = j;
    renderEnv(j);
  } catch {
    $("#aiInsight").textContent = "Some data is temporarily unavailable. Weather services may be unreachable.";
  }
}

function renderEnv(j) {
  const w = j.weather;
  if (w) {
    $("#heroIcon").textContent = w.icon || "🌡️";
    $("#heroTemp").textContent = w.temp != null ? Math.round(w.temp) : "--";
    $("#heroCond").textContent = w.condition || "—";
    $("#heroFeels").textContent = w.feels != null ? Math.round(w.feels) : "--";
    $("#heroHum").textContent = w.humidity ?? "--";
    $("#heroWind").textContent = w.wind != null ? Math.round(w.wind) : "--";
    const pop = j.next_rain ? j.next_rain.probability : null;
    $("#heroPop").textContent = pop != null ? pop : (w.precip > 0 ? "☔" : "0");
    $("#wxFresh").textContent = j._demo ? "DEMO DATA — NOT LIVE" : ("updated " + new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }));
    $("#wxBadge").textContent = j._demo ? "DEMO DATA — NOT LIVE" : "LIVE DATA";
    $("#wxBadge").className = "badge " + (j._demo ? "muted" : "live");
  }
  // Risk pills
  const fr = j.flood_risk || {};
  setPill("#riskFlood", fr.risk_level || "—", fr.risk_level);
  setPill("#riskAir", j.air ? j.air.category : "—", j.air && j.air.us_aqi <= 50 ? "good" : j.air && j.air.us_aqi <= 100 ? "warn" : "bad");
  const eqc = j.earthquakes ? j.earthquakes.count : 0;
  setPill("#riskEq", eqc ? eqc + " nearby" : "None significant", eqc ? "warn" : "good");
  setPill("#riskRain", j.next_rain ? `~${j.next_rain.hours_from_now}h (${j.next_rain.probability}%)` : "None in 48h", j.next_rain ? "warn" : "good");
  // Insight
  $("#aiInsight").innerHTML = buildInsight(j);
  // Hourly
  if (j.hourly) {
    $("#hourlyStrip").innerHTML = j.hourly.slice(0, 24).map((h) => `
      <div class="h-cell"><div class="t">${h.time.slice(11, 16)}</div><div class="i">${h.icon}</div>
      <div class="p">${Math.round(h.temp)}°</div><div class="r">${h.pop ?? 0}%</div></div>`).join("");
  } else {
    $("#hourlyStrip").innerHTML = `<div class="muted-sm" style="padding:8px">Hourly forecast ${j._demo ? "hidden in demo scenario" : "unavailable"}.</div>`;
  }
  if (j.daily) {
    $("#dailyList").innerHTML = j.daily.map((d) => `
      <div class="d-row"><span>${new Date(d.date).toLocaleDateString([], { weekday: "short" })}</span>
      <span>${d.icon}</span><span>${d.cond}</span>
      <span class="pp">${d.pop_max ?? 0}% 💧</span>
      <span><b>${Math.round(d.tmax)}°</b> / ${Math.round(d.tmin)}°</span></div>`).join("");
  } else {
    $("#dailyList").innerHTML = `<div class="muted-sm" style="padding:8px">Daily forecast ${j._demo ? "hidden in demo scenario" : "unavailable"}.</div>`;
  }
}

function setPill(sel, text, cls) {
  const el = $(sel);
  el.textContent = text;
  el.className = "risk-pill " + (cls || "");
}

function buildInsight(j) {
  const parts = [];
  const w = j.weather, fr = j.flood_risk;
  if (w) parts.push(`It's currently <b>${Math.round(w.temp)}°C</b> and ${(w.condition || "").toLowerCase()} in ${state.loc.name.split(",")[0]}.`);
  if (j.next_rain) parts.push(`Rain looks likely within about <b>${j.next_rain.hours_from_now} hour(s)</b> (${j.next_rain.probability}% probability) — carrying an umbrella would be sensible.`);
  else parts.push("No significant rain is expected in the next 48 hours.");
  if (fr && fr.risk_level) {
    parts.push(`Estimated local flood risk is <b>${fr.risk_level}</b>${fr.risk_score != null ? ` (score ${fr.risk_score}/100)` : ""}.`);
    if (["HIGH", "VERY HIGH"].includes(fr.risk_level) && fr.factors) parts.push(`Key drivers: ${fr.factors.slice(0, 2).join("; ")}.`);
  }
  if (j.air) parts.push(`Air quality is <b>${j.air.category}</b>${j.air.us_aqi ? ` (US AQI ${j.air.us_aqi})` : ""}.`);
  if (j.earthquakes && j.earthquakes.count > 0) {
    const e = j.earthquakes.nearest[0];
    parts.push(`A magnitude ${e.mag} earthquake was detected ${e.distance_km} km away — no action is usually needed at that distance, but stay aware.`);
  }
  if (j._demo) parts.push(`<br><span class="badge muted">DEMO DATA — NOT LIVE</span>`);
  return parts.join(" ") || "No data available yet.";
}

/* ---------- Location picker ---------- */
$("#locChip").addEventListener("click", () => $("#locModal").classList.remove("hidden"));
$("#locClose").addEventListener("click", () => $("#locModal").classList.add("hidden"));
let searchT;
$("#locSearch").addEventListener("input", (e) => {
  clearTimeout(searchT); // debounce
  searchT = setTimeout(async () => {
    const q = e.target.value.trim();
    if (q.length < 2) return;
    try {
      const r = await fetch(`/api/geocode?q=${encodeURIComponent(q)}`);
      const j = await r.json();
      $("#locResults").innerHTML = (j.results || []).map((r2, i) =>
        `<div class="loc-item" data-i="${i}">${r2.name}<div class="sub">${[r2.region, r2.country].filter(Boolean).join(", ")}</div></div>`).join("") || `<div class="muted-sm" style="padding:8px">No matches — try GPS or coordinates.</div>`;
      $$("#locResults .loc-item").forEach((el) => el.addEventListener("click", () => {
        const r2 = j.results[+el.dataset.i];
        setLocation({ name: r2.label, lat: r2.lat, lon: r2.lon });
        $("#locModal").classList.add("hidden");
      }));
    } catch { $("#locResults").innerHTML = `<div class="muted-sm" style="padding:8px">Search unavailable.</div>`; }
  }, 400);
});
$("#locGps").addEventListener("click", useGPS);
$("#gpsBtn").addEventListener("click", useGPS);
function useGPS() {
  if (!navigator.geolocation) return alert("Geolocation is not supported by this device.");
  navigator.geolocation.getCurrentPosition(
    (p) => { setLocation({ name: `My location (${p.coords.latitude.toFixed(3)}, ${p.coords.longitude.toFixed(3)})`, lat: p.coords.latitude, lon: p.coords.longitude }); $("#locModal").classList.add("hidden"); },
    () => alert("Could not get your location. Check browser permission."),
    { timeout: 10000 });
}
$("#locCoords").addEventListener("click", () => {
  const v = prompt("Enter coordinates as: latitude, longitude");
  if (!v) return;
  const [a, b] = v.split(",").map((x) => parseFloat(x.trim()));
  if (isNaN(a) || isNaN(b) || Math.abs(a) > 90 || Math.abs(b) > 180) return alert("Invalid coordinates.");
  setLocation({ name: `Pinned (${a.toFixed(3)}, ${b.toFixed(3)})`, lat: a, lon: b });
  $("#locModal").classList.add("hidden");
});
function setLocation(l) {
  state.loc = l;
  $("#locName").textContent = l.name;
  loadEnvironment();
  if (state.map) syncMap();
}

/* ---------- Save place ---------- */
$("#saveLocBtn").addEventListener("click", async () => {
  const kind = prompt("Save as: Home / College / My Colony / Work / Family / Custom", "My Colony");
  if (kind === null) return;
  await fetch("/api/places", { method: "POST", headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ name: `${kind} — ${state.loc.name.split(",")[0]}`, lat: state.loc.lat, lon: state.loc.lon, label: state.loc.name, kind: kind.toLowerCase().replace(/\s+/g, "_") }) });
  alert("Saved to My Places.");
});
async function loadPlaces() {
  const r = await fetch("/api/places"); const j = await r.json();
  $("#placesList").innerHTML = (j.places || []).map((p) => `
    <div class="place-card" data-lat="${p.lat}" data-lon="${p.lon}" data-name="${p.label || p.name}">
      <button class="p-del" data-id="${p.id}" title="Delete">✕</button>
      <div class="p-name">${iconFor(p.kind)} ${p.name}</div>
      <div class="p-label">${p.label || ""}</div>
      <div class="p-label">${p.lat.toFixed(3)}, ${p.lon.toFixed(3)}</div>
    </div>`).join("") || `<div class="empty-state">No saved places yet.<br>Use “＋ Save” on the home screen to save Home, College, or My Colony.</div>`;
  $$(".place-card").forEach((c) => c.addEventListener("click", (e) => {
    if (e.target.classList.contains("p-del")) return;
    setLocation({ name: c.dataset.name, lat: +c.dataset.lat, lon: +c.dataset.lon });
    switchView("home");
  }));
  $$(".p-del").forEach((b) => b.addEventListener("click", async () => {
    await fetch(`/api/places/${b.dataset.id}`, { method: "DELETE" }); loadPlaces();
  }));
}
function iconFor(k) { return { home: "🏠", college: "🎓", my_colony: "🏘️", colony: "🏘️", work: "💼", family: "👪" }[k] || "📍"; }

/* ---------- Alerts ---------- */
async function loadAlerts() {
  const r = await fetch("/api/alerts"); const j = await r.json();
  renderAlerts(j.alerts || []);
}
$("#evalAlertsBtn").addEventListener("click", async () => {
  $("#evalAlertsBtn").textContent = "Checking…";
  const r = await fetch("/api/alerts/evaluate", { method: "POST" });
  const j = await r.json();
  renderAlerts(j.alerts || []);
  $("#evalAlertsBtn").textContent = "↻ Check saved places";
});
function renderAlerts(alerts) {
  if (state.demo && DEMO[demoScenario] && demoScenario === "earthquake") {
    const e = DEMO.earthquake.earthquakes.nearest[0];
    alerts = [{ type: "earthquake", severity: "event", location: state.loc.name, title: `Earthquake detected M${e.mag} (simulated)`,
      detail: `${e.place} — ${e.distance_km} km away, depth ${e.depth_km} km.`, source: "DEMO", data_status: "DEMO DATA — NOT LIVE", ts: new Date().toISOString() }];
  }
  $("#alertsList").innerHTML = alerts.length ? alerts.slice().reverse().map((a) => `
    <div class="alert-card ${a.type === "earthquake" ? "event" : a.severity === "info" ? "info" : ""}">
      <div class="a-top">
        <span class="badge ${a.data_status === "VERIFIED EVENT" ? "event" : a.data_status === "LIVE DATA" ? "live" : a.data_status && a.data_status.startsWith("DEMO") ? "muted" : "ai"}">${a.data_status || "AI ASSESSMENT"}</span>
        <span class="a-title">${a.title}</span>
      </div>
      <div>${a.detail}</div>
      ${a.factors ? `<ul class="muted-sm" style="margin:6px 0 0 18px">${a.factors.map((f) => `<li>${f}</li>`).join("")}</ul>` : ""}
      <div class="a-meta">${a.location} • ${new Date(a.ts).toLocaleString()} • Source: ${a.source}</div>
    </div>`).join("")
    : `<div class="empty-state">No alerts right now.<br>Save places and press “Check saved places” to evaluate deterministic alert rules.</div>`;
}

/* ---------- Map ---------- */
function initMap() {
  if (state.map) { setTimeout(() => state.map.invalidateSize(), 100); return; }
  state.map = L.map("map", { attributionControl: true }).setView([state.loc.lat, state.loc.lon], 11);
  L.tileLayer("https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png", {
    attribution: '© OpenStreetMap contributors © CARTO', maxZoom: 19 }).addTo(state.map);
  state.map.on("click", (e) => {
    setLocation({ name: `Pinned (${e.latlng.lat.toFixed(3)}, ${e.latlng.lng.toFixed(3)})`, lat: e.latlng.lat, lon: e.latlng.lng });
  });
  setTimeout(() => { state.map.invalidateSize(); syncMap(); }, 150);
}
async function syncMap() {
  const m = state.map; if (!m) return;
  state.markers.forEach((mk) => m.removeLayer(mk)); state.markers = [];
  const cur = L.circleMarker([state.loc.lat, state.loc.lon], { radius: 9, color: "#4da3ff", fillColor: "#4da3ff", fillOpacity: .8 })
    .addTo(m).bindPopup(`<b>${state.loc.name}</b>`);
  state.markers.push(cur);
  m.setView([state.loc.lat, state.loc.lon], 11);
  // saved places
  try {
    const j = await (await fetch("/api/places")).json();
    (j.places || []).forEach((p) => {
      state.markers.push(L.circleMarker([p.lat, p.lon], { radius: 7, color: "#37e0c8", fillColor: "#37e0c8", fillOpacity: .7 })
        .addTo(m).bindPopup(`📍 <b>${p.name}</b>`));
    });
  } catch {}
  // earthquakes
  try {
    const j = await (await fetch(`/api/earthquakes?lat=${state.loc.lat}&lon=${state.loc.lon}&radius=800&days=30`)).json();
    (j.nearby || []).forEach((e) => {
      if (e.lat == null) return;
      state.markers.push(L.circleMarker([e.lat, e.lon], { radius: 5 + (e.mag || 3), color: "#f45a6d", fillColor: "#f45a6d", fillOpacity: .5 })
        .addTo(m).bindPopup(`<b>M${e.mag}</b> ${e.place}<br>${e.distance_km} km away • depth ${e.depth_km} km`));
    });
  } catch {}
}

/* ---------- Chat ---------- */
function addMsg(role, text, meta) {
  const d = document.createElement("div");
  d.className = "msg " + role;
  d.textContent = text;
  if (meta && role === "bot") {
    const b = document.createElement("div");
    b.className = "m-badge";
    if (meta.data_status) b.innerHTML += `<span class="badge ${meta.data_status === "VERIFIED EVENT" ? "event" : meta.data_status === "LIVE DATA" ? "live" : "ai"}">${meta.data_status}</span>`;
    if (meta.source) b.innerHTML += `<span class="badge muted">${meta.source}</span>`;
    d.appendChild(b);
  }
  $("#chatLog").appendChild(d);
  d.scrollIntoView({ behavior: "smooth", block: "end" });
  return d;
}
async function sendChat(text) {
  if (!text.trim()) return;
  addMsg("user", text);
  const typing = document.createElement("div");
  typing.className = "typing"; typing.textContent = "Checking data…";
  $("#chatLog").appendChild(typing); typing.scrollIntoView();
  if (state.demo) {
    typing.remove();
    addMsg("bot", buildDemoAnswer(text), { data_status: "DEMO", source: "DEMO DATA — NOT LIVE" });
    return;
  }
  try {
    const r = await fetch("/api/chat", { method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ message: text, lat: state.loc.lat, lon: state.loc.lon, name: state.loc.name, history: state.chatHistory.slice(-6) }) });
    const j = await r.json();
    typing.remove();
    if (j.error) { addMsg("bot", j.error, null); return; }
    state.chatHistory.push({ role: "user", content: text }, { role: "assistant", content: j.answer });
    addMsg("bot", j.answer, j);
    if (j.tool === "calculate_flood_risk" && j.data && j.data.risk_level) renderEnv({ ...(state.env || {}), flood_risk: j.data, weather: (state.env || {}).weather });
  } catch { typing.remove(); addMsg("bot", "The assistant is unreachable right now. Weather pages still work from live data."); }
}
$("#chatForm").addEventListener("submit", (e) => { e.preventDefault(); sendChat($("#chatInput").value); $("#chatInput").value = ""; });
$("#quickAsk").addEventListener("submit", (e) => { e.preventDefault(); const v = $("#quickAskInput").value; $("#quickAskInput").value = ""; switchView("ask"); sendChat(v); });
$$(".chip").forEach((c) => c.addEventListener("click", () => { switchView("ask"); sendChat(c.dataset.q); }));

function buildDemoAnswer(q) {
  const sc = DEMO[demoScenario];
  q = q.toLowerCase();
  if (q.includes("flood")) {
    const f = sc.flood_risk;
    return `Your selected location currently has ${f.risk_level} estimated flood risk (score ${f.risk_score}/100).\n\nKey factors:\n• ${f.factors.join("\n• ")}\n\nThis is an AI-assisted environmental risk estimate, not an official flood warning. It cannot resolve individual colony roads or drains.`;
  }
  if (q.includes("rain")) return sc.next_rain ? `Rain is expected ${sc.next_rain.time === "now" ? "now" : "within ~" + sc.next_rain.hours_from_now + "h"} (probability ${sc.next_rain.probability}%).` : "No significant rain expected in the next 48h in this scenario.";
  if (q.includes("air")) return `Air quality is ${sc.air.category} (US AQI ${sc.air.us_aqi}).`;
  if (q.includes("earthquake")) return sc.earthquakes.count ? `A simulated magnitude ${sc.earthquakes.nearest[0].mag} earthquake was detected ${sc.earthquakes.nearest[0].distance_km} km away.` : "No significant nearby earthquake activity in this scenario.";
  return `Demo scenario "${demoScenario}": ${sc.weather.condition}, ${sc.weather.temp}°C. Flood risk ${sc.flood_risk.risk_level}, air ${sc.air.category}.`;
}

/* ---------- Photo analysis ---------- */
$("#photoBtn").addEventListener("click", () => $("#photoInput").click());
$("#photoInput").addEventListener("change", async (e) => {
  const f = e.target.files[0]; if (!f) return;
  const box = $("#photoResult");
  box.classList.remove("hidden");
  box.innerHTML = "Analyzing photo…";
  const fd = new FormData();
  fd.append("file", f);
  try {
    const r = await fetch(`/api/analyze-image?lat=${state.loc.lat}&lon=${state.loc.lon}&name=${encodeURIComponent(state.loc.name)}`, { method: "POST", body: fd });
    const j = await r.json();
    if (j.error) { box.innerHTML = `<span class="badge muted">AI ASSESSMENT</span> ${j.error}`; return; }
    const o = j.observation || {};
    let html = `<span class="badge ai">AI ASSESSMENT</span> <b>${o.summary || "Photo analyzed."}</b>`;
    if (o.observations && o.observations.length) html += `<ul>${o.observations.map((x) => `<li>${x}</li>`).join("")}</ul>`;
    if (j.combined && j.combined.flood_risk) {
      const fr = j.combined.flood_risk;
      html += `<div class="muted-sm">Combined with live data: estimated flood risk here is <b>${fr.risk_level}</b> (${fr.risk_score}/100). The image alone cannot establish exact water depth or road safety.</div>`;
    }
    html += `<div class="muted-sm" style="margin-top:6px">Image observations are evidence, not a deterministic forecast.</div>`;
    box.innerHTML = html;
  } catch { box.innerHTML = "Photo analysis failed. The AI provider may be unavailable."; }
  e.target.value = "";
});

/* ---------- Demo mode ---------- */
$("#demoToggle").addEventListener("change", (e) => {
  state.demo = e.target.checked;
  $("#demoBanner").classList.toggle("hidden", !state.demo);
  if (state.demo) {
    const c = prompt("Demo scenario: heavy_rain / flood / earthquake / poor_air / normal", "heavy_rain");
    if (c && (DEMO[c] !== undefined)) demoScenario = c;
  }
  loadEnvironment();
});

/* ---------- Settings ---------- */
async function initSettings() {
  try {
    const j = await (await fetch("/api/ai/status")).json();
    setPill("#aiStatus", j.available ? "Configured (" + j.providers.join(", ") + ")" : "Not configured", j.available ? "good" : "warn");
  } catch { setPill("#aiStatus", "Unknown", "warn"); }
}

/* ---------- Boot ---------- */
$("#locName").textContent = state.loc.name;
loadEnvironment();
initSettings();
