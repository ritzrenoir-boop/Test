# Sentinel AI — Weather & Local Hazard Intelligence

## Run
```
pip install -r requirements.txt
cd sentinel-ai && python3 main.py        # or: uvicorn main:app --port 8000
# open http://localhost:8000
```

## AI configuration (optional — app works without it)
Set one of these env vars before starting (server-side only, never in frontend):
- OPENAI_API_KEY  (also enables photo vision)
- GEMINI_API_KEY
- ANTHROPIC_API_KEY
Optional overrides: SENTINEL_OPENAI_MODEL, SENTINEL_GEMINI_MODEL, SENTINEL_ANTHROPIC_MODEL, SENTINEL_VISION_MODEL

## Data providers (all free/open, no keys)
- Open-Meteo: weather, hourly/daily forecast, geocoding, elevation (CC BY 4.0)
- Open-Meteo Air Quality (CAMS)
- Open-Meteo Flood (GloFAS river discharge — regional/river-level only)
- USGS: earthquakes
- OpenStreetMap/CARTO: map tiles

## Architecture
UI (static/) · Data services (provider layer) · Deterministic flood-risk engine ·
AI agent (tool-calling, provider-agnostic) · Persistence (data/store.json) ·
Alert evaluation (deterministic rules) · Media (photo analysis)

## Known limitations
- Flood API is river-level/regional; cannot resolve individual colony roads — used as one weighted input.
- Vision/chat require an AI provider key; everything else works without one.
- No authentication (by design); saved places are per-server local JSON.
