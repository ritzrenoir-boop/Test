"""
SENTINEL AI - Weather & Local Hazard Intelligence
Full-stack backend: provider layer, deterministic flood engine, AI agent,
alerts, vision, persistence. The AI is NOT the source of truth.
"""
import os, json, math, time, base64, asyncio, datetime, threading
from typing import Optional, List, Dict, Any
import httpx
from fastapi import FastAPI, Query, UploadFile, File, Body
from fastapi.responses import FileResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel

BASE = os.path.dirname(os.path.abspath(__file__))
DATA_DIR = os.path.join(BASE, "data")
os.makedirs(DATA_DIR, exist_ok=True)
STORE_PATH = os.path.join(DATA_DIR, "store.json")

app = FastAPI(title="Sentinel AI")

# ----------------------------------------------------------------------------
# Config / AI provider (replaceable, not hardcoded). Do NOT fabricate creds.
# ----------------------------------------------------------------------------
AI_CONFIG = {
    "provider": os.environ.get("SENTINEL_AI_PROVIDER", "auto"),  # openai|anthropic|gemini|auto|none
    "openai_key": os.environ.get("OPENAI_API_KEY", ""),
    "anthropic_key": os.environ.get("ANTHROPIC_API_KEY", ""),
    "gemini_key": os.environ.get("GEMINI_API_KEY", ""),
    "openai_model": os.environ.get("SENTINEL_OPENAI_MODEL", "gpt-4o-mini"),
    "anthropic_model": os.environ.get("SENTINEL_ANTHROPIC_MODEL", "claude-3-5-haiku-latest"),
    "gemini_model": os.environ.get("SENTINEL_GEMINI_MODEL", "gemini-1.5-flash"),
    "vision_model": os.environ.get("SENTINEL_VISION_MODEL", "gpt-4o-mini"),
}
MAX_IMAGE_BYTES = 8 * 1024 * 1024  # 8 MB limit

def ai_available() -> bool:
    return bool(AI_CONFIG["openai_key"] or AI_CONFIG["anthropic_key"] or AI_CONFIG["gemini_key"])

# ----------------------------------------------------------------------------
# Simple TTL cache (performance: dedupe + avoid calling APIs on every render)
# ----------------------------------------------------------------------------
_cache: Dict[str, Any] = {}
def cache_get(key):
    e = _cache.get(key)
    if e and time.time() < e["exp"]:
        return e["val"]
    return None
def cache_set(key, val, ttl=300):
    _cache[key] = {"val": val, "exp": time.time() + ttl}

# ----------------------------------------------------------------------------
# Persistence (local JSON). No unnecessary auth. Only save what user intends.
# ----------------------------------------------------------------------------
_store_lock = threading.Lock()
def load_store():
    if not os.path.exists(STORE_PATH):
        return {"places": [], "settings": {"units": "metric"}, "alerts": [], "prev_risk": {}}
    try:
        with open(STORE_PATH) as f:
            s = json.load(f)
        for k in ["places", "alerts"]:
            s.setdefault(k, [])
        s.setdefault("settings", {"units": "metric"})
        s.setdefault("prev_risk", {})
        return s
    except Exception:
        return {"places": [], "settings": {"units": "metric"}, "alerts": [], "prev_risk": {}}
def save_store(s):
    with _store_lock:
        tmp = STORE_PATH + ".tmp"
        with open(tmp, "w") as f:
            json.dump(s, f)
        os.replace(tmp, STORE_PATH)

# ----------------------------------------------------------------------------
# HTTP helper
# ----------------------------------------------------------------------------
async def http_get(url, params=None, timeout=20):
    async with httpx.AsyncClient(timeout=timeout) as c:
        r = await c.get(url, params=params, headers={"User-Agent": "SentinelAI/1.0"})
        r.raise_for_status()
        return r.json()

# ----------------------------------------------------------------------------
# WEATHER CODE MAP (WMO)
# ----------------------------------------------------------------------------
WMO = {
    0:("Clear sky","☀️"),1:("Mainly clear","🌤️"),2:("Partly cloudy","⛅"),3:("Overcast","☁️"),
    45:("Fog","🌫️"),48:("Depositing rime fog","🌫️"),51:("Light drizzle","🌦️"),53:("Drizzle","🌦️"),
    55:("Dense drizzle","🌧️"),56:("Freezing drizzle","🌧️"),57:("Freezing drizzle","🌧️"),
    61:("Slight rain","🌧️"),63:("Moderate rain","🌧️"),65:("Heavy rain","🌧️"),
    66:("Freezing rain","🌧️"),67:("Freezing rain","🌧️"),71:("Slight snow","🌨️"),73:("Snow","🌨️"),
    75:("Heavy snow","❄️"),77:("Snow grains","❄️"),80:("Slight showers","🌦️"),81:("Showers","🌦️"),
    82:("Violent showers","🌧️"),85:("Snow showers","🌨️"),86:("Snow showers","🌨️"),
    95:("Thunderstorm","⛈️"),96:("Thunderstorm w/ hail","⛈️"),99:("Thunderstorm w/ hail","⛈️"),
}
def wmo_desc(code):
    return WMO.get(code, ("Unknown", "🌡️"))

# ----------------------------------------------------------------------------
# PROVIDER LAYER - data services (isolated from UI/AI)
# ----------------------------------------------------------------------------
async def search_location(query: str):
    key = f"geo:{query.lower()}"
    c = cache_get(key)
    if c: return c
    data = await http_get("https://geocoding-api.open-meteo.com/v1/search",
                          {"name": query, "count": 8, "language": "en", "format": "json"})
    out = []
    for r in data.get("results", []):
        out.append({
            "name": r.get("name"),
            "lat": r.get("latitude"), "lon": r.get("longitude"),
            "region": r.get("admin1", ""), "country": r.get("country", ""),
            "label": ", ".join([x for x in [r.get("name"), r.get("admin1"), r.get("country")] if x]),
        })
    cache_set(key, out, 3600)
    return out

async def get_elevation(lat, lon):
    key = f"elev:{round(lat,3)}:{round(lon,3)}"
    c = cache_get(key)
    if c is not None: return c
    try:
        d = await http_get("https://api.open-meteo.com/v1/elevation", {"latitude": lat, "longitude": lon})
        e = d.get("elevation", [None])[0]
    except Exception:
        e = None
    cache_set(key, e, 86400)
    return e

async def get_weather(lat, lon):
    """Current + hourly + daily from Open-Meteo (free, no key)."""
    key = f"wx:{round(lat,2)}:{round(lon,2)}"
    c = cache_get(key)
    if c: return c
    params = {
        "latitude": lat, "longitude": lon, "timezone": "auto",
        "current": "temperature_2m,relative_humidity_2m,apparent_temperature,is_day,precipitation,rain,showers,weather_code,cloud_cover,pressure_msl,wind_speed_10m,wind_direction_10m,wind_gusts_10m",
        "hourly": "temperature_2m,precipitation_probability,precipitation,rain,showers,weather_code,cloud_cover,relative_humidity_2m,wind_speed_10m,soil_moisture_0_to_1cm",
        "daily": "weather_code,temperature_2m_max,temperature_2m_min,sunrise,sunset,precipitation_sum,precipitation_probability_max,uv_index_max,wind_speed_10m_max",
        "forecast_days": 7,
    }
    d = await http_get("https://api.open-meteo.com/v1/forecast", params)
    d["_fetched_at"] = datetime.datetime.now(datetime.timezone.utc).isoformat()
    cache_set(key, d, 300)
    return d

async def get_air_quality(lat, lon):
    key = f"aqi:{round(lat,2)}:{round(lon,2)}"
    c = cache_get(key)
    if c: return c
    try:
        d = await http_get("https://air-quality-api.open-meteo.com/v1/air-quality", {
            "latitude": lat, "longitude": lon, "timezone": "auto",
            "current": "us_aqi,pm10,pm2_5,carbon_monoxide,nitrogen_dioxide,sulphur_dioxide,ozone",
            "hourly": "us_aqi,pm2_5", "forecast_days": 2,
        })
        d["_fetched_at"] = datetime.datetime.now(datetime.timezone.utc).isoformat()
    except Exception:
        d = None
    cache_set(key, d, 600)
    return d

async def get_flood_indicators(lat, lon):
    """Open-Meteo Flood API (GloFAS river discharge). Coarse/river-level, use as ONE input."""
    key = f"flood:{round(lat,2)}:{round(lon,2)}"
    c = cache_get(key)
    if c is not None: return c
    try:
        d = await http_get("https://flood-api.open-meteo.com/v1/flood", {
            "latitude": lat, "longitude": lon,
            "daily": "river_discharge,river_discharge_mean,river_discharge_max",
            "forecast_days": 7,
        })
        d["_fetched_at"] = datetime.datetime.now(datetime.timezone.utc).isoformat()
        if "daily" not in d or not d["daily"].get("river_discharge"):
            d = None
    except Exception:
        d = None
    cache_set(key, d, 1800)
    return d

async def get_earthquakes(lat=None, lon=None, radius_km=500, days=7, min_mag=2.5):
    key = f"eq:{days}:{min_mag}"
    c = cache_get(key)
    if c is None:
        start = (datetime.datetime.now(datetime.timezone.utc) - datetime.timedelta(days=days)).strftime("%Y-%m-%d")
        try:
            d = await http_get("https://earthquake.usgs.gov/fdsnws/event/1/query", {
                "format": "geojson", "starttime": start, "minmagnitude": min_mag,
                "orderby": "time", "limit": 200,
            }, timeout=25)
        except Exception:
            return None
        feats = []
        for f in d.get("features", []):
            p = f.get("properties", {}); g = f.get("geometry", {})
            coords = g.get("coordinates", [None, None, None])
            feats.append({
                "id": f.get("id"), "mag": p.get("mag"), "place": p.get("place"),
                "time": p.get("time"), "depth_km": coords[2] if len(coords) > 2 else None,
                "lon": coords[0] if len(coords) > 0 else None,
                "lat": coords[1] if len(coords) > 1 else None,
                "alert": p.get("alert"), "tsunami": p.get("tsunami"), "url": p.get("url"),
                "type": p.get("type"), "title": p.get("title"),
            })
        c = feats
        cache_set(key, c, 600)
    if lat is not None and lon is not None:
        for e in c:
            e["distance_km"] = round(haversine(lat, lon, e["lat"], e["lon"]), 1) if e["lat"] else None
        near = [e for e in c if e.get("distance_km") is not None and e["distance_km"] <= radius_km]
        near.sort(key=lambda x: x["distance_km"])
        return {"nearby": near, "count": len(near), "radius_km": radius_km}
    c2 = sorted(c, key=lambda x: -(x["time"] or 0))
    return {"recent": c2[:50]}

def haversine(lat1, lon1, lat2, lon2):
    R = 6371.0
    p1, p2 = math.radians(lat1), math.radians(lat2)
    dp = math.radians(lat2 - lat1); dl = math.radians(lon2 - lon1)
    a = math.sin(dp/2)**2 + math.cos(p1)*math.cos(p2)*math.sin(dl/2)**2
    return 2*R*math.asin(math.sqrt(a))

# ----------------------------------------------------------------------------
# DETERMINISTIC FLOOD-RISK ENGINE  (the AI does NOT generate or change this)
# Same inputs -> same score. Explainable & reproducible.
# ----------------------------------------------------------------------------
def risk_level(score):
    if score < 30: return "LOW"
    if score < 60: return "MODERATE"
    if score < 80: return "HIGH"
    return "VERY HIGH"

def calculate_flood_risk(wx: dict, elev: Optional[float], flood: Optional[dict], name="selected location"):
    factors, limitations = [], []
    now_iso = datetime.datetime.now(datetime.timezone.utc).isoformat()
    if not wx or "hourly" not in wx:
        return {
            "location": name, "risk_score": None, "risk_level": "INSUFFICIENT DATA",
            "factors": [], "confidence": "none", "data_quality": "insufficient",
            "data_limitations": ["Weather forecast unavailable"], "generated_at": now_iso,
        }
    h = wx["hourly"]; tz_off = wx.get("utc_offset_seconds", 0)
    # next 24h window in location local time
    times = h.get("time", [])
    precip = h.get("precipitation", [0]*len(times))
    pop = h.get("precipitation_probability", [0]*len(times))
    soil = h.get("soil_moisture_0_to_1cm", [None]*len(times))
    # find current index (local now)
    now_local = datetime.datetime.now(datetime.timezone.utc) + datetime.timedelta(seconds=tz_off)
    now_str = now_local.strftime("%Y-%m-%dT%H:00")
    try:
        start = times.index(now_str)
    except ValueError:
        start = 0
    sl = slice(start, min(start+24, len(times)))
    p24 = precip[sl]; pop24 = pop[sl]; soil24 = soil[sl]
    rain_sum = round(sum(x or 0 for x in p24), 1)
    max_int = round(max((x or 0 for x in p24), default=0), 1)
    max_pop = max((x or 0 for x in pop24), default=0)
    max_soil = max((x for x in soil24 if x is not None), default=None)

    # --- component scores (each 0-100), deterministic ---
    # rainfall accumulation (0-40mm+)
    s_rain = min(100, (rain_sum / 40.0) * 100)
    # intensity (0-15mm/h+)
    s_int = min(100, (max_int / 15.0) * 100)
    # probability
    s_pop = max_pop
    # elevation (lower => higher risk). 0-100; <50m=100 ... >=1500m=0
    if elev is not None:
        s_elev = max(0, min(100, (1 - (elev / 1500.0)) * 100))
        factors.append(f"Low elevation ({elev:.0f} m) increases water-accumulation potential")
    else:
        s_elev = 40; limitations.append("Elevation unavailable")
    # soil moisture saturation
    if max_soil is not None:
        s_soil = min(100, max_soil * 250)  # 0.4 => 100
        if max_soil > 0.35: factors.append(f"High near-surface soil moisture ({max_soil:.2f}) reduces infiltration")
    else:
        s_soil = 30; limitations.append("Soil moisture unavailable")
    # river discharge anomaly (GloFAS) - regional/river-level ONLY
    s_river = None
    if flood and flood.get("daily"):
        dis = flood["daily"].get("river_discharge", [])
        mean = flood["daily"].get("river_discharge_mean", [])
        pairs = [(d, m) for d, m in zip(dis, mean) if d is not None and m]
        if pairs:
            ratio = max(d/m for d, m in pairs)
            s_river = max(0, min(100, (ratio - 1.0) * 100))
            if ratio > 1.3: factors.append(f"Regional river discharge {ratio:.1f}× its average (river-level indicator)")
        else:
            limitations.append("River-discharge indicator has no data at this point")
    else:
        limitations.append("River-discharge (regional) indicator unavailable for this location")

    if rain_sum >= 20: factors.append(f"Heavy forecast rainfall accumulation ({rain_sum} mm in 24h)")
    elif rain_sum >= 8: factors.append(f"Moderate forecast rainfall ({rain_sum} mm in 24h)")
    if max_int >= 7: factors.append(f"High rainfall intensity (up to {max_int} mm/h)")
    if max_pop >= 70: factors.append(f"High precipitation probability ({max_pop}%)")

    # weighted combination
    weights = [("rain", s_rain, 0.30), ("intensity", s_int, 0.22),
               ("probability", s_pop, 0.15), ("elevation", s_elev, 0.13), ("soil", s_soil, 0.10)]
    if s_river is not None:
        weights.append(("river", s_river, 0.10))
    tw = sum(w for _, _, w in weights)
    score = round(sum(s*w for _, s, w in weights) / tw)
    score = max(0, min(100, score))

    data_q = "good" if (s_river is not None and elev is not None and max_soil is not None) else \
             ("moderate" if (elev is not None) else "limited")
    conf = "moderate" if data_q == "good" else ("low-moderate" if data_q == "moderate" else "low")
    limitations.append("Assessment is regional/estimated; it cannot resolve individual colony roads or drains.")
    return {
        "location": name, "risk_score": score, "risk_level": risk_level(score),
        "factors": factors or ["No significant flood-driving factors in the next 24h"],
        "confidence": conf, "data_quality": data_q,
        "components": {"rain_sum_mm": rain_sum, "max_intensity_mmh": max_int,
                       "max_probability_pct": max_pop, "elevation_m": elev,
                       "soil_moisture": max_soil, "river_indicator": s_river},
        "data_limitations": limitations, "generated_at": now_iso,
        "disclaimer": "AI-assisted environmental risk estimate, not an official flood warning.",
    }

# ----------------------------------------------------------------------------
# SUMMARY builders for AI context / UI
# ----------------------------------------------------------------------------
def summarize_weather(wx):
    cur = wx.get("current", {})
    code = cur.get("weather_code", 0)
    desc, icon = wmo_desc(code)
    return {
        "temp": cur.get("temperature_2m"), "feels": cur.get("apparent_temperature"),
        "humidity": cur.get("relative_humidity_2m"), "condition": desc, "icon": icon,
        "precip": cur.get("precipitation"), "cloud": cur.get("cloud_cover"),
        "wind": cur.get("wind_speed_10m"), "wind_dir": cur.get("wind_direction_10m"),
        "gusts": cur.get("wind_gusts_10m"), "is_day": cur.get("is_day"),
        "time": cur.get("time"), "fetched_at": wx.get("_fetched_at"),
        "timezone": wx.get("timezone"), "utc_offset": wx.get("utc_offset_seconds", 0),
    }

def next_rain_window(wx, max_hours=48):
    h = wx.get("hourly", {}); times = h.get("time", [])
    pop = h.get("precipitation_probability", []); pr = h.get("precipitation", [])
    tz = wx.get("utc_offset_seconds", 0)
    now_local = datetime.datetime.now(datetime.timezone.utc) + datetime.timedelta(seconds=tz)
    now_str = now_local.strftime("%Y-%m-%dT%H:00")
    try: start = times.index(now_str)
    except ValueError: start = 0
    for i in range(start, min(start+max_hours, len(times))):
        p = pop[i] if i < len(pop) else 0
        mm = pr[i] if i < len(pr) else 0
        if (p or 0) >= 40 or (mm or 0) >= 0.3:
            t = times[i]
            return {"time": t, "probability": p, "precip_mm": mm,
                    "hours_from_now": i - start}
    return None

# ----------------------------------------------------------------------------
# DATA-ASSEMBLY ENDPOINT (parallel fetch)
# ----------------------------------------------------------------------------
@app.get("/api/environment")
async def api_environment(lat: float, lon: float, name: str = "Selected location"):
    wx_t = get_weather(lat, lon)
    aqi_t = get_air_quality(lat, lon)
    elev_t = get_elevation(lat, lon)
    flood_t = get_flood_indicators(lat, lon)
    eq_t = get_earthquakes(lat, lon, radius_km=500, days=30)
    wx, aqi, elev, flood, eq = await asyncio.gather(wx_t, aqi_t, elev_t, flood_t, eq_t)
    risk = calculate_flood_risk(wx, elev, flood, name)
    nr = next_rain_window(wx) if wx else None
    # AQI summary
    aqi_sum = None
    if aqi and aqi.get("current"):
        c = aqi["current"]
        aqi_sum = {"us_aqi": c.get("us_aqi"), "pm2_5": c.get("pm2_5"), "pm10": c.get("pm10"),
                   "ozone": c.get("ozone"), "no2": c.get("nitrogen_dioxide"),
                   "category": aqi_category(c.get("us_aqi")), "fetched_at": aqi.get("_fetched_at")}
    eq_sum = None
    if eq is not None:
        eq_sum = {"count": eq["count"], "nearest": eq["nearby"][:5], "radius_km": eq["radius_km"]}
    return {
        "location": {"name": name, "lat": lat, "lon": lon},
        "weather": summarize_weather(wx) if wx else None,
        "next_rain": nr, "air": aqi_sum, "elevation_m": elev,
        "flood_risk": risk, "earthquakes": eq_sum,
        "hourly": pack_hourly(wx), "daily": pack_daily(wx),
        "status": {
            "weather": bool(wx), "air": bool(aqi), "elevation": elev is not None,
            "flood_indicators": bool(flood), "earthquakes": eq is not None,
            "ai": ai_available(),
        },
    }

def pack_hourly(wx, n=48):
    if not wx or "hourly" not in wx: return None
    h = wx["hourly"]; tz = wx.get("utc_offset_seconds", 0)
    now_local = datetime.datetime.now(datetime.timezone.utc) + datetime.timedelta(seconds=tz)
    now_str = now_local.strftime("%Y-%m-%dT%H:00")
    times = h.get("time", [])
    try: start = times.index(now_str)
    except ValueError: start = 0
    out = []
    for i in range(start, min(start+n, len(times))):
        code = h.get("weather_code", [0]*len(times))[i]
        d, ic = wmo_desc(code)
        out.append({"time": times[i], "temp": h["temperature_2m"][i],
                    "pop": h.get("precipitation_probability", [0]*len(times))[i],
                    "precip": h.get("precipitation", [0]*len(times))[i],
                    "cloud": h.get("cloud_cover", [0]*len(times))[i],
                    "icon": ic, "cond": d})
    return out

def pack_daily(wx):
    if not wx or "daily" not in wx: return None
    d = wx["daily"]; out = []
    for i, t in enumerate(d.get("time", [])):
        code = d.get("weather_code", [0]*len(d.get("time", [])))[i]
        desc, ic = wmo_desc(code)
        out.append({"date": t, "icon": ic, "cond": desc,
                    "tmax": d.get("temperature_2m_max", [None]*7)[i],
                    "tmin": d.get("temperature_2m_min", [None]*7)[i],
                    "sunrise": d.get("sunrise", [None]*7)[i], "sunset": d.get("sunset", [None]*7)[i],
                    "precip_sum": d.get("precipitation_sum", [None]*7)[i],
                    "pop_max": d.get("precipitation_probability_max", [None]*7)[i],
                    "uv": d.get("uv_index_max", [None]*7)[i]})
    return out

def aqi_category(a):
    if a is None: return "Unknown"
    if a <= 50: return "Good"
    if a <= 100: return "Moderate"
    if a <= 150: return "Unhealthy for sensitive groups"
    if a <= 200: return "Unhealthy"
    if a <= 300: return "Very unhealthy"
    return "Hazardous"

# ----------------------------------------------------------------------------
# LOCATION endpoints
# ----------------------------------------------------------------------------
@app.get("/api/geocode")
async def api_geocode(q: str = Query(..., min_length=1)):
    try:
        return {"results": await search_location(q)}
    except Exception as e:
        return JSONResponse({"error": "Geocoding unavailable", "results": []}, status_code=502)

@app.get("/api/reverse")
async def api_reverse(lat: float, lon: float):
    # coarse reverse label via nearest big cities using geocoding is unreliable;
    # return coords-based label (frontend may refine). Keep honest.
    return {"label": f"{lat:.3f}, {lon:.3f}"}

# ----------------------------------------------------------------------------
# EARTHQUAKES endpoint
# ----------------------------------------------------------------------------
@app.get("/api/earthquakes")
async def api_eq(lat: Optional[float] = None, lon: Optional[float] = None,
                 radius: int = 500, days: int = 30, minmag: float = 2.5):
    res = await get_earthquakes(lat, lon, radius, days, minmag) if lat is not None else await get_earthquakes(days=days, min_mag=minmag)
    if res is None:
        return JSONResponse({"error": "Earthquake data temporarily unavailable"}, status_code=502)
    return res

# ----------------------------------------------------------------------------
# SAVED PLACES
# ----------------------------------------------------------------------------
class Place(BaseModel):
    id: Optional[str] = None
    name: str
    lat: float
    lon: float
    label: Optional[str] = ""
    kind: Optional[str] = "custom"  # home|college|colony|work|family|custom
    alerts: Optional[dict] = {}

@app.get("/api/places")
def get_places():
    return {"places": load_store()["places"]}

@app.post("/api/places")
def add_place(p: Place):
    s = load_store()
    import uuid
    p.id = p.id or uuid.uuid4().hex[:10]
    s["places"] = [x for x in s["places"] if x.get("id") != p.id]
    s["places"].append(p.dict())
    save_store(s)
    return {"ok": True, "place": p.dict()}

@app.delete("/api/places/{pid}")
def del_place(pid: str):
    s = load_store()
    s["places"] = [x for x in s["places"] if x.get("id") != pid]
    save_store(s)
    return {"ok": True}

# ----------------------------------------------------------------------------
# ALERTS (deterministic evaluation on saved places)
# ----------------------------------------------------------------------------
@app.get("/api/alerts")
def get_alerts():
    return {"alerts": load_store()["alerts"][-50:]}

async def evaluate_alerts_for_place(place):
    """Deterministic rule-based alert generation; AI only words it later."""
    alerts = []
    lat, lon, name = place["lat"], place["lon"], place["name"]
    try:
        wx = await get_weather(lat, lon)
    except Exception:
        wx = None
    elev = await get_elevation(lat, lon)
    flood = await get_flood_indicators(lat, lon)
    now = datetime.datetime.now(datetime.timezone.utc).isoformat()
    if wx:
        risk = calculate_flood_risk(wx, elev, flood, name)
        s = load_store()
        prev = s["prev_risk"].get(place["id"])
        if prev and prev != risk["risk_level"] and risk["risk_level"] in ("MODERATE","HIGH","VERY HIGH"):
            order = ["LOW","MODERATE","HIGH","VERY HIGH"]
            if order.index(risk["risk_level"]) > order.index(prev):
                alerts.append({"type":"flood_risk","severity":risk["risk_level"],"location":name,
                    "title":f"Flood risk increased to {risk['risk_level']}",
                    "detail":f"Estimated flood risk moved from {prev} to {risk['risk_level']} (score {risk['risk_score']}).",
                    "factors":risk["factors"],"source":"Sentinel deterministic engine","data_status":"AI ASSESSMENT","ts":now})
        s["prev_risk"][place["id"]] = risk["risk_level"]
        save_store(s)
        # rain soon
        nr = next_rain_window(wx, 12)
        if nr and nr["hours_from_now"] <= 6 and (nr["probability"] or 0) >= 60:
            alerts.append({"type":"rain","severity":"info","location":name,
                "title":"Rain expected soon",
                "detail":f"Rain likely within ~{nr['hours_from_now']}h (probability {nr['probability']}%).",
                "source":"Open-Meteo","data_status":"LIVE DATA","ts":now})
    # earthquakes (deterministic event detection)
    eq = await get_earthquakes(lat, lon, radius_km=300, days=1, min_mag=4.0)
    if eq and eq["nearby"]:
        e = eq["nearby"][0]
        alerts.append({"type":"earthquake","severity":"event","location":name,
            "title":f"Earthquake detected M{e['mag']}",
            "detail":f"{e['place']} — {e['distance_km']} km away, depth {e['depth_km']} km.",
            "source":"USGS","data_status":"VERIFIED EVENT","ts":now,"event":e})
    # air quality deterioration
    aqi = await get_air_quality(lat, lon)
    if aqi and aqi.get("current") and (aqi["current"].get("us_aqi") or 0) > 150:
        alerts.append({"type":"air","severity":"warning","location":name,
            "title":"Poor air quality",
            "detail":f"US AQI {aqi['current']['us_aqi']} ({aqi_category(aqi['current']['us_aqi'])}).",
            "source":"Open-Meteo AQ","data_status":"LIVE DATA","ts":now})
    return alerts

@app.post("/api/alerts/evaluate")
async def eval_alerts():
    s = load_store()
    new_alerts = []
    for p in s["places"]:
        try:
            new_alerts += await evaluate_alerts_for_place(p)
        except Exception:
            continue
    if new_alerts:
        # dedupe rough by type+location+title
        existing = {(a["type"], a["location"], a["title"]) for a in s["alerts"][-100:]}
        for a in new_alerts:
            if (a["type"], a["location"], a["title"]) not in existing:
                s["alerts"].append(a)
        save_store(s)
    return {"added": len(new_alerts), "alerts": s["alerts"][-50:]}

# ----------------------------------------------------------------------------
# VISION / PHOTO ANALYSIS  (observations are NOT ground truth)
# ----------------------------------------------------------------------------
VISION_PROMPT = (
    "You are analyzing a user photo of a road/colony/drain/outdoor area for environmental observation. "
    "Describe ONLY what is visibly present. Look for: standing water, waterlogging, blocked or overflowing drain, "
    "muddy road, visible flooding, road obstruction, debris, poor visibility. Do NOT predict or forecast. "
    "Do NOT claim this proves future flooding. Be concise. "
    "Return JSON with keys: observations (list of strings), visible_water (true/false/null), "
    "summary (one sentence), confidence (low/moderate/high)."
)

@app.post("/api/analyze-image")
async def analyze_image(file: UploadFile = File(...), lat: Optional[float] = None,
                        lon: Optional[float] = None, name: Optional[str] = None):
    content = await file.read()
    if len(content) > MAX_IMAGE_BYTES:
        return JSONResponse({"error": "Image too large (max 8 MB)"}, status_code=413)
    if file.content_type not in ("image/jpeg","image/png","image/webp","image/gif"):
        return JSONResponse({"error": "Unsupported image type"}, status_code=415)
    if not ai_available():
        return JSONResponse({"error": "AI vision unavailable — configure an AI provider",
                             "ai_unavailable": True}, status_code=503)
    b64 = base64.b64encode(content).decode()
    obs = await run_vision(b64, file.content_type)
    combined = None
    if lat is not None and lon is not None:
        try:
            wx, elev, flood = await asyncio.gather(get_weather(lat, lon), get_elevation(lat, lon), get_flood_indicators(lat, lon))
            risk = calculate_flood_risk(wx, elev, flood, name or "photo location")
            combined = {"weather": summarize_weather(wx), "flood_risk": risk}
        except Exception:
            combined = None
    return {"observation": obs, "combined": combined, "data_status": "AI ASSESSMENT",
            "note": "Image observations are evidence, not a deterministic forecast or official warning."}

async def run_vision(b64, mime):
    # Try OpenAI -> Anthropic -> Gemini
    if AI_CONFIG["openai_key"]:
        try:
            async with httpx.AsyncClient(timeout=60) as c:
                r = await c.post("https://api.openai.com/v1/chat/completions",
                    headers={"Authorization": f"Bearer {AI_CONFIG['openai_key']}"},
                    json={"model": AI_CONFIG["vision_model"],
                          "messages":[{"role":"user","content":[
                              {"type":"text","text":VISION_PROMPT},
                              {"type":"image_url","image_url":{"url":f"data:{mime};base64,{b64}"}}]}],
                          "response_format":{"type":"json_object"}})
                j = r.json()
                return json.loads(j["choices"][0]["message"]["content"])
        except Exception:
            pass
    if AI_CONFIG["gemini_key"]:
        try:
            async with httpx.AsyncClient(timeout=60) as c:
                r = await c.post(
                    f"https://generativelanguage.googleapis.com/v1beta/models/{AI_CONFIG['gemini_model']}:generateContent?key={AI_CONFIG['gemini_key']}",
                    json={"contents":[{"parts":[{"text":VISION_PROMPT},
                        {"inline_data":{"mime_type":mime,"data":b64}}]}]})
                j = r.json()
                txt = j["candidates"][0]["content"]["parts"][0]["text"]
                return json.loads(extract_json(txt))
        except Exception:
            pass
    if AI_CONFIG["anthropic_key"]:
        try:
            async with httpx.AsyncClient(timeout=60) as c:
                r = await c.post("https://api.anthropic.com/v1/messages",
                    headers={"x-api-key":AI_CONFIG["anthropic_key"],"anthropic-version":"2023-06-01"},
                    json={"model":AI_CONFIG["anthropic_model"],"max_tokens":800,
                          "messages":[{"role":"user","content":[
                              {"type":"image","source":{"type":"base64","media_type":mime,"data":b64}},
                              {"type":"text","text":VISION_PROMPT}]}]})
                j = r.json()
                return json.loads(extract_json(j["content"][0]["text"]))
        except Exception:
            pass
    return {"observations":["Vision analysis failed"],"visible_water":None,
            "summary":"Could not analyze image.","confidence":"low"}

def extract_json(txt):
    txt = txt.strip()
    if txt.startswith("```"):
        txt = txt.strip("`")
        if txt.startswith("json"): txt = txt[4:]
    s, e = txt.find("{"), txt.rfind("}")
    return txt[s:e+1] if s != -1 else txt

# ----------------------------------------------------------------------------
# AI AGENT (tool-calling). AI selects tools; it does NOT invent data.
# ----------------------------------------------------------------------------
AGENT_TOOLS = [
    {"name":"search_location","description":"Resolve a place name to coordinates",
     "params":{"query":"string"}},
    {"name":"get_current_weather","description":"Current conditions at lat/lon",
     "params":{"lat":"float","lon":"float","name":"string"}},
    {"name":"get_forecast","description":"Hourly+daily forecast, next-rain window",
     "params":{"lat":"float","lon":"float","name":"string"}},
    {"name":"get_air_quality","description":"Air quality / AQI at lat/lon",
     "params":{"lat":"float","lon":"float"}},
    {"name":"calculate_flood_risk","description":"Deterministic localized flood-risk score",
     "params":{"lat":"float","lon":"float","name":"string"}},
    {"name":"get_earthquakes","description":"Recent earthquakes near lat/lon",
     "params":{"lat":"float","lon":"float","radius_km":"int"}},
    {"name":"compare_locations","description":"Compare two places' forecasts",
     "params":{"lat_a":"float","lon_a":"float","name_a":"string","lat_b":"float","lon_b":"float","name_b":"string"}},
]

class ChatReq(BaseModel):
    message: str
    lat: Optional[float] = None
    lon: Optional[float] = None
    name: Optional[str] = None
    history: Optional[List[dict]] = []

@app.get("/api/ai/status")
def ai_status():
    provs = []
    if AI_CONFIG["openai_key"]: provs.append("openai")
    if AI_CONFIG["gemini_key"]: provs.append("gemini")
    if AI_CONFIG["anthropic_key"]: provs.append("anthropic")
    return {"available": ai_available(), "providers": provs}

@app.post("/api/chat")
async def chat(req: ChatReq):
    if not ai_available():
        return JSONResponse({"error": "AI assistant unavailable — configure an AI provider to enable conversational analysis.",
                             "ai_unavailable": True}, status_code=503)
    try:
        result = await run_agent(req.message, req.lat, req.lon, req.name, req.history or [])
        return result
    except Exception as e:
        return JSONResponse({"error": f"AI error: {str(e)[:200]}"}, status_code=500)

SYSTEM_PROMPT = """You are Sentinel, the AI assistant inside Sentinel AI (weather & local-hazard intelligence).
You answer questions about weather, flood risk, air quality, and earthquakes using the provided data tools.
Rules:
- NEVER invent weather, earthquake, flood or AQI values. Only use tool results.
- The flood-risk score comes ONLY from the deterministic calculate_flood_risk tool. Never compute or change it yourself.
- If data is missing/unavailable, say so honestly. Communicate uncertainty.
- Be concise, plain-language, and actionable. The user is not a meteorologist.
- Distinguish verified/live data from AI assessment. Use phrases like "estimated", "conditions suggest".
- Never claim an area "will definitely flood" or that an earthquake "will happen".
- When the user says "here"/"my location"/"my colony" and current location context is given, use those coordinates.
First decide which tool(s) to call, then answer from the returned data."""

async def run_agent(message, lat, lon, name, history):
    ctx = f"\nCurrent location context: {name} (lat {lat}, lon {lon})." if lat is not None else ""
    plan = await llm_tool_call(message, ctx, history)
    tool_used = plan.get("tool"); args = plan.get("args", {})
    data, data_status, source = None, None, None
    if tool_used and tool_used != "none":
        data, source, data_status = await dispatch_tool(tool_used, args, lat, lon, name)
    answer = await llm_answer(message, ctx, tool_used, data, history)
    return {"answer": answer, "tool": tool_used, "data_status": data_status,
            "source": source, "data": data}

async def dispatch_tool(tool, args, def_lat, def_lon, def_name):
    la = args.get("lat", def_lat); lo = args.get("lon", def_lon)
    nm = args.get("name", def_name or "selected location")
    try:
        if tool == "search_location":
            res = await search_location(args.get("query",""))
            return {"results": res}, "Open-Meteo Geocoding", "LIVE DATA"
        if tool == "get_current_weather":
            wx = await get_weather(la, lo)
            return summarize_weather(wx), "Open-Meteo", "LIVE DATA"
        if tool == "get_forecast":
            wx = await get_weather(la, lo)
            return {"current": summarize_weather(wx), "next_rain": next_rain_window(wx),
                    "daily": pack_daily(wx), "hourly": (pack_hourly(wx, 24) or [])[:24]}, "Open-Meteo", "LIVE DATA"
        if tool == "get_air_quality":
            aqi = await get_air_quality(la, lo)
            if not aqi: return {"error":"Air quality unavailable"}, "Open-Meteo AQ", None
            c = aqi["current"]
            return {"us_aqi": c.get("us_aqi"), "category": aqi_category(c.get("us_aqi")),
                    "pm2_5": c.get("pm2_5"), "pm10": c.get("pm10"),
                    "ozone": c.get("ozone"), "no2": c.get("nitrogen_dioxide")}, "Open-Meteo AQ", "LIVE DATA"
        if tool == "calculate_flood_risk":
            wx, elev, flood = await asyncio.gather(get_weather(la,lo), get_elevation(la,lo), get_flood_indicators(la,lo))
            return calculate_flood_risk(wx, elev, flood, nm), "Sentinel deterministic engine", "AI ASSESSMENT"
        if tool == "get_earthquakes":
            r = await get_earthquakes(la, lo, int(args.get("radius_km",500)), 30)
            if r is None: return {"error":"Earthquake data temporarily unavailable"}, "USGS", None
            return r, "USGS", "VERIFIED EVENT"
        if tool == "compare_locations":
            wa, wb = await asyncio.gather(get_weather(args["lat_a"],args["lon_a"]),
                                          get_weather(args["lat_b"],args["lon_b"]))
            return ({"a":{"name":args["name_a"],"current":summarize_weather(wa),"next_rain":next_rain_window(wa),"daily":(pack_daily(wa) or [])[:3]},
                    "b":{"name":args["name_b"],"current":summarize_weather(wb),"next_rain":next_rain_window(wb),"daily":(pack_daily(wb) or [])[:3]}},
                    "Open-Meteo", "LIVE DATA")
    except Exception as e:
        return {"error": f"Tool '{tool}' failed: {str(e)[:120]}"}, None, None
    return None, None, None

async def llm_tool_call(message, ctx, history):
    tool_desc = "\n".join([f"- {t['name']}({', '.join(t['params'].keys())}): {t['description']}" for t in AGENT_TOOLS])
    prompt = f"""{ctx}
Available tools:
{tool_desc}

User question: "{message}"

Respond with ONLY a JSON object choosing the single best tool:
{{"tool":"<name or 'none'>","args":{{...}}}}
If the question needs location resolution first (a place name with no coordinates), use search_location.
If it's a general greeting or doesn't need data, use "none"."""
    txt = await llm_text(prompt, system="You are a routing module. Output only valid JSON.")
    try:
        return json.loads(extract_json(txt))
    except Exception:
        return {"tool":"none","args":{}}

async def llm_answer(message, ctx, tool, data, history):
    data_block = json.dumps(data, indent=2) if data is not None else "null"
    prompt = f"""{ctx}
User question: "{message}"
Tool used: {tool}
Tool returned data:
{data_block}

Now answer the user helpfully and concisely based ONLY on the data above (if any).
If data is null or has an error, say the info is unavailable and answer generally without inventing values."""
    return await llm_text(prompt, system=SYSTEM_PROMPT)

async def llm_text(prompt, system=""):
    """Provider-agnostic text call. Tries OpenAI -> Gemini -> Anthropic."""
    if AI_CONFIG["openai_key"]:
        try:
            async with httpx.AsyncClient(timeout=60) as c:
                r = await c.post("https://api.openai.com/v1/chat/completions",
                    headers={"Authorization": f"Bearer {AI_CONFIG['openai_key']}"},
                    json={"model": AI_CONFIG["openai_model"],
                          "messages":[{"role":"system","content":system},
                                      {"role":"user","content":prompt}], "temperature":0.3})
                j = r.json()
                return j["choices"][0]["message"]["content"]
        except Exception:
            pass
    if AI_CONFIG["gemini_key"]:
        try:
            async with httpx.AsyncClient(timeout=60) as c:
                r = await c.post(
                    f"https://generativelanguage.googleapis.com/v1beta/models/{AI_CONFIG['gemini_model']}:generateContent?key={AI_CONFIG['gemini_key']}",
                    json={"systemInstruction":{"parts":[{"text":system}]},
                          "contents":[{"parts":[{"text":prompt}]}]})
                j = r.json()
                return j["candidates"][0]["content"]["parts"][0]["text"]
        except Exception:
            pass
    if AI_CONFIG["anthropic_key"]:
        try:
            async with httpx.AsyncClient(timeout=60) as c:
                r = await c.post("https://api.anthropic.com/v1/messages",
                    headers={"x-api-key":AI_CONFIG["anthropic_key"],"anthropic-version":"2023-06-01"},
                    json={"model":AI_CONFIG["anthropic_model"],"max_tokens":900,
                          "system":system,"messages":[{"role":"user","content":prompt}]})
                j = r.json()
                return j["content"][0]["text"]
        except Exception:
            pass
    raise RuntimeError("No AI provider configured or all providers failed")

# ----------------------------------------------------------------------------
# Static frontend
# ----------------------------------------------------------------------------
app.mount("/static", StaticFiles(directory=os.path.join(BASE, "static")), name="static")

@app.get("/")
def index():
    return FileResponse(os.path.join(BASE, "static", "index.html"))

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=int(os.environ.get("PORT", 8000)))
